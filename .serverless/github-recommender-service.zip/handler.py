def hello(event, context):
    return { "message": "Go Serverless v1.0! Your function executed successfully!", "event": event }


def newUser(event, context):
    username = event["username"]
    from github3 import login
    gr = login('githubrec', password= 'openseasame1')
    user = gr.user(username)
    if user:
        return user.name
    else:
        return "error"
    #return { "username": event["username"] }
